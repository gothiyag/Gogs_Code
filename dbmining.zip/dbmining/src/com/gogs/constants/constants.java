package com.gogs.constants;

/**
 * 
 * @author gogs
 *
 */

public interface constants {

	String NO_DATA_FOUND = "NO_DATA_FOUND";
	String DATA_RETRIVED = "DATA_RETRIVED";
	String DATA_INSERTED = "DATA_INSERTED";
	String NO_DATA = "NO_DATA";
	String SUCCESS = "SUCCESS";
	String FAILURE = "FAILURE";
	String DATA_INSERTED_SUCCESSFULLY = "DATA_INSERTED_SUCCESSFULLY";
	String INSERTION_FAILED = "INSERTION_FAILED";
	String NO_PROPER_INPUT = "NO_PROPER_INPUT";

}
