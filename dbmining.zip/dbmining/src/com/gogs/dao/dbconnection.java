package com.gogs.dao;



import java.io.FileNotFoundException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

/**
 * 
 * @author gogs
 *
 */

public class dbconnection {

	public Connection getConnection() throws Exception {
		String db_server, db_name, db_username, db_password, db_port = null;
		try {
			System.out.println("Entered in to Database Connection Method..");

			InputStream inputStream = this.getClass().getClassLoader()
					.getResourceAsStream("db.properties");
			if (inputStream == null) {
				throw new FileNotFoundException(
						"property file not found in the classpath");
			}
			Properties prop = new Properties();
			prop.load(inputStream);

			System.out.println("Properth File Loaded...");

			db_server = prop.getProperty("db_server");
			System.out.println("The DB server is:" + db_server);
			db_name = prop.getProperty("db_name");
			System.out.println("The DB Name is:" + db_name);
			db_username = prop.getProperty("db_username");
			System.out.println("The DB Username  is:" + db_username);
			db_password = prop.getProperty("db_password");
			System.out.println("The DB Password is:" + db_password);
			db_port = prop.getProperty("db_port");
			System.out.println("The DB Port is:" + db_port);

			String connectionURL = "jdbc:mysql://" + db_server + ":" + db_port
					+ "/" + db_name;
			System.out.println("The Connection URL  is:jdbc:mysql://"
					+ db_server + ":" + db_port + "/" + db_name);
			Connection connection = null;
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			connection = DriverManager.getConnection(connectionURL,
					db_username, db_password);
			return connection;
		} catch (SQLException e) {
			throw e;
		} catch (Exception e) {
			throw e;
		}
	}

}