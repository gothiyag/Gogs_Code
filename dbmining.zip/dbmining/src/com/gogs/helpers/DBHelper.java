package com.gogs.helpers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.gogs.constants.constants;

import com.gogs.resource.StatusResponse;
import com.gogs.utils.ParsingUtils;

/**
 * 
 * @author gogs
 *
 */

public class DBHelper {

	private static Logger logger = Logger.getLogger(DBHelper.class);

	public Connection con;

	public StatusResponse insertIntoDB(String title, String url, String desc,
			String query_text, String source) {

		ParsingUtils util = new ParsingUtils();

		StatusResponse res = null;

		if (title == null || title.isEmpty()) {
			title = validateData();
		}
		if (url == null || url.isEmpty()) {
			url = validateData();
		}
		if (desc == null || desc.isEmpty()) {
			desc = validateData();
		}

		try {
			Connection con = getCon();
			// PreparedStatement st =
			// con.prepareStatement("insert IGNORE into search_records(search_title,search_url,search_desc,source) VALUES ('"+title+"'"+",'"+url+"'"+",'"+desc+"'"+",'"+source+"' )");
			PreparedStatement st = con
					.prepareStatement("insert IGNORE into search_results(title,url,description,query_text,source) VALUES (?,?,?,?,?)");
			st.setString(1, title);
			st.setString(2, url);
			st.setString(3, desc);
			st.setString(4, query_text);
			st.setString(5, source);
			st.executeUpdate();
			// con.close();

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		logger.debug("The title is:" + title);
		logger.debug("The url is:" + url);
		logger.debug("The desc is:" + desc);
		System.out.println("The title is:" + title);
		System.out.println("The url is:" + url);
		System.out.println("The desc is:" + desc);

		return res;

	}

	public StatusResponse insertIntoDB(String title, String url,
			String query_text, String source) {

		ParsingUtils util = new ParsingUtils();

		StatusResponse res = null;

		if (title == null || title.isEmpty()) {
			title = validateData();
		}
		if (url == null || url.isEmpty()) {
			url = validateData();
		}

		try {
			Connection con = getCon();
			// PreparedStatement st =
			// con.prepareStatement("insert IGNORE into search_records(search_title,search_url,search_desc,source) VALUES ('"+title+"'"+",'"+url+"'"+",'"+desc+"'"+",'"+source+"' )");
			PreparedStatement st = con
					.prepareStatement("insert IGNORE into related_results(title,url,query_text,source) VALUES (?,?,?,?)");
			st.setString(1, title);
			st.setString(2, url);
			st.setString(3, query_text);
			st.setString(4, source);
			st.executeUpdate();
			// con.close();

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.debug("The title is:" + title);
		logger.debug("The url is:" + url);
		System.out.println("The title is:" + title);
		System.out.println("The url is:" + url);

		return res;

	}

	public String validateData() {
		String processed = constants.NO_DATA;

		return processed;

	}

	/**
	 * @return the con
	 */
	public Connection getCon() {
		return con;
	}

	/**
	 * @param con
	 *            the con to set
	 */
	public void setCon(Connection con) {
		this.con = con;
	}

}
