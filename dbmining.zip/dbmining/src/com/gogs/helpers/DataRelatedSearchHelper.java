package com.gogs.helpers;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.gogs.resource.dbDetails;

import com.gogs.utils.ParsingUtils;

/**
 * 
 * @author gogs
 *
 */

public class DataRelatedSearchHelper {

	private static Logger logger = Logger.getLogger(DataRelatedSearchHelper.class);
	public ArrayList<dbDetails> DisplaySingleAttributesOnly(Connection con,
			dbDetails detail) {
		
		logger.debug("Entered in DisplaySingle Attr method");
		String attribute = detail.getAttr();
		String source = detail.getResource();

		ArrayList<dbDetails> dataList = new ArrayList<dbDetails>();
		ParsingUtils util = new ParsingUtils();

		try {

			// PreparedStatement st =
			// con.prepareStatement("insert IGNORE into search_records(search_title,search_url,search_desc,source) VALUES ('"+title+"'"+",'"+url+"'"+",'"+desc+"'"+",'"+source+"' )");
			Statement st = con.createStatement();
			logger.debug("The query is:" + "SELECT " + attribute
					+ ",source FROM datamining.related_results where source='"
					+ source + "'");
			System.out.println("The query is:" + "SELECT " + attribute
					+ ",source FROM datamining.related_results where source='"
					+ source + "'");
			PreparedStatement ps = con
					.prepareStatement("SELECT "
							+ attribute
							+ ",source,query_text FROM datamining.related_results where source='"
							+ source + "'");
			// ps.setString(1,uname);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				// SearchResultDetails detail = new SearchResultDetails();
				detail = new dbDetails();

				if (attribute.equals("title")) {
					detail.setTitle(rs.getString(attribute));
				}
				if (attribute.equals("url")) {
					detail.setUrl(rs.getString(attribute));
				}

				// detail.setAttr(rs.getString(attribute));

				detail.setResource(rs.getString("source"));
				detail.setQuery_text(rs.getString("query_text"));

				dataList.add(detail);
				// list.setDbContent(displayAttr);
			}

			con.close();

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dataList;

	}

	public ArrayList<dbDetails> DisplayAllResults(Connection con,
			dbDetails detail) {

		logger.debug("Entered in to DisplayAllResults method..");
		String source = detail.getResource();

		ArrayList<dbDetails> dataList = new ArrayList<dbDetails>();
		ParsingUtils util = new ParsingUtils();

		try {

			Statement st = con.createStatement();

			// System.out.println("The query is:"+"SELECT '"+attribute+"' FROM datamining.search_results where source='"+source+"'");
			PreparedStatement ps = null;
			if (source.equals("ALL")) {
				ps = con.prepareStatement("SELECT * FROM datamining.related_results");
			} else {
				ps = con.prepareStatement("SELECT * FROM datamining.related_results where source='"
						+ source + "'");

			}
			// ps.setString(1,uname);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				detail = new dbDetails();

				detail.setTitle(rs.getString("title"));
				detail.setUrl(rs.getString("url"));

				detail.setQuery_text(rs.getString("query_text"));
				detail.setResource(rs.getString("source"));

				dataList.add(detail);

			}

			con.close();

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dataList;

	}

	public ArrayList<dbDetails> CompareAttributes(Connection con,
			dbDetails detail) {
		logger.debug("Entered in to CompareAttr method..");
		String attribute = detail.getAttr();

		ArrayList<dbDetails> dataList = new ArrayList<dbDetails>();

		try {

			// PreparedStatement st =
			// con.prepareStatement("insert IGNORE into search_records(search_title,search_url,search_desc,source) VALUES ('"+title+"'"+",'"+url+"'"+",'"+desc+"'"+",'"+source+"' )");
			Statement st = con.createStatement();
			logger.debug("SELECT query_text,source," + attribute
					+ " from datamining.related_results where " + attribute
					+ " in (select " + attribute
					+ " from datamining.search_results group by " + attribute
					+ " having count(" + attribute + ") > 1)");
			System.out.println("SELECT query_text,source," + attribute
					+ " from datamining.related_results where " + attribute
					+ " in (select " + attribute
					+ " from datamining.search_results group by " + attribute
					+ " having count(" + attribute + ") > 1)");
			PreparedStatement ps = con
					.prepareStatement("SELECT query_text,source," + attribute
							+ " from datamining.related_results where "
							+ attribute + " in (select " + attribute
							+ " from datamining.search_results group by "
							+ attribute + " having count(" + attribute
							+ ") > 1)");
			// ps.setString(1,uname);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				detail = new dbDetails();

				detail.setAttr(rs.getString(attribute));
				detail.setResource(rs.getString("source"));
				detail.setQuery_text(rs.getString("query_text"));

				dataList.add(detail);

			}

			con.close();

		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return dataList;

	}

}
