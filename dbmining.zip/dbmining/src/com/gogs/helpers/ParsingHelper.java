package com.gogs.helpers;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.gogs.constants.constants;

import com.gogs.resource.InsertResponse;
import com.gogs.resource.StatusResponse;
import com.gogs.resource.dbDetails;
import com.gogs.utils.ParsingUtils;

/**
 * 
 * @author gogs
 *
 */

public class ParsingHelper {

	private static Logger logger = Logger.getLogger(ParsingHelper.class);

	public InsertResponse googleSearchResults(String Url, dbDetails detail,
			Connection con) {
		String query_text = detail.getQuery_text();
		InsertResponse res = new InsertResponse();
		ArrayList<StatusResponse> response = new ArrayList<StatusResponse>();

		// String response=null;
		// StatusResponse res = new StatusResponse();
		try {
			String source = "google.com";
			ParsingUtils utils = new ParsingUtils();

			Document doc = utils.getDoc(Url, query_text);
			Elements links = doc.select("li[class=g]");
			for (Element link : links) {

				Elements titles = link.select("h3[class=r]");
				String title = titles.text();

				Elements urls = link.select("div[class=s]");

				String url = "";
				for (Element urltrim : urls) {

					Elements formatURL = urltrim.getElementsByTag("cite");
					url = formatURL.text();

				}

				Elements bodies = link.select("span[class=st]");

				String body = bodies.text();

				DBHelper db = new DBHelper();
				db.setCon(con);
				db.insertIntoDB(title, url, body, query_text, source);
				logger.debug("Inserted all the data successfully..");
				// System.out.println("Title: "+title);
				// System.out.println("URL is:"+url);
				// System.out.println("Body: "+body+"\n");
				// res.setCode(constants.SUCCESS);
				// res.setMessage(constants.DATA_INSERTED_SUCCESSFULLY);
			}

			// res.setResponseStatus(constants.SUCCESS);

		} catch (Exception e) {
			e.printStackTrace();
			// res.setCode(constants.FAILURE);
			// res.setMessage(constants.INSERTION_FAILED);
			res.setResponseStatus(constants.FAILURE);
			logger.debug("unable to insert data.");

		}
		return res;

	}

	public InsertResponse googleRelatedResults(String Url, dbDetails detail,
			Connection con) {

		InsertResponse res = new InsertResponse();
		ArrayList<StatusResponse> response = new ArrayList<StatusResponse>();
		String query_text = detail.getQuery_text();

		// String response=null;
		try {
			String source = "google.com";
			ParsingUtils utils = new ParsingUtils();

			Document doc = utils.getDoc(Url, query_text);
			Elements links = doc.select("p[class=msrl]");

			// System.out.println("The content under div is:"+links);
			for (Element link : links) {

				Elements titles = link.getElementsByTag("p");
				String title = titles.text();
				System.out.println("The title for Related Search is:" + title);

				Elements urls = link.getElementsByTag("a");
				for (Element url : urls) {
					String linkHref = url.attr("href");
					// System.out.println("URLS:"+linkHref.replaceAll("ie=UTF-8&",
					// "").split("&revid=")[0]);
					// System.out.println("URLS:"+linkHref);
					String formated_url = utils.googleURLEncoder(linkHref);
					// System.out.println("THE URL is:"+utils.googleURLEncoder(linkHref));

					DBHelper db = new DBHelper();
					db.setCon(con);
					db.insertIntoDB(title, formated_url, query_text, source);
					logger.debug("Inserted all the data successfully..");
					// System.out.println("Title: "+title);
					// System.out.println("URL is:"+url);
					// System.out.println("Body: "+body+"\n");
					// res.setCode(constants.SUCCESS);
					// res.setMessage(constants.DATA_INSERTED_SUCCESSFULLY);

				}

			}

			// res.setResponseStatus(constants.FAILURE);

		} catch (Exception e) {

			e.printStackTrace();
			res.setResponseStatus(constants.FAILURE);
			logger.debug("Unable to insert data ");

		}
		return res;

	}

	public InsertResponse BingSearchResults(String SearchOption,
			dbDetails detail, Connection con) throws ParseException {
		List<StatusResponse> response = new ArrayList<StatusResponse>();
		String query_text = detail.getQuery_text();

		InsertResponse res = new InsertResponse();
		// String response=null;
		try {
			String source = "bing.com";
			ParsingUtils util = new ParsingUtils();

			/*
			 * JSONParser parser = new JSONParser(); JSONObject parsedJson =
			 * (JSONObject)parser.parse(util.getBingResults());
			 * 
			 * JSONObject root_obj=(JSONObject) parsedJson.get("d");
			 * 
			 * JSONArray obj = (JSONArray)root_obj.get("results");
			 */

			JSONArray obj = util.getJSONObject(SearchOption, query_text);
			for (int i = 0; i < obj.size(); i++) {

				JSONObject obj1 = (JSONObject) obj.get(i);

				// System.out.println("The Title is"+obj1.get("Title"));
				// System.out.println("The DESC is"+obj1.get("Description"));
				// System.out.println("The Url is"+obj1.get("BingUrl"));

				DBHelper db = new DBHelper();
				db.setCon(con);
				if (SearchOption.equals("Web")) {
					System.out.println("The SearchOption is:" + SearchOption);
					String title = (String) obj1.get("Title");
					String url = (String) obj1.get("Url");
					String body = (String) obj1.get("Description");
					db.insertIntoDB(title, url, body, query_text, source);
				}
				if (SearchOption.equals("RelatedSearch")) {
					System.out.println("The SearchOption is:" + SearchOption);
					String title = (String) obj1.get("Title");
					String url = (String) obj1.get("BingUrl");
					db.insertIntoDB(title, url, query_text, source);
				} else {

					res.setResponseStatus(constants.FAILURE);
					res.setResponseErrorCode(constants.NO_PROPER_INPUT);
					res.setResponseErrorMessage("Please give input as 'Web' / 'RelatedSearch'");
					logger.debug("Please give input as 'Web' / 'RelatedSearch'");

				}

			}

			res.setResponseStatus(constants.SUCCESS);
			res.setResponseErrorCode(constants.DATA_INSERTED);
			res.setResponseErrorMessage("Bing Search and Related Data Searched and Inserted Successfully");
			logger.debug("Bing Search and Related Data Searched and Inserted Successfully");

		} catch (Exception e) {
			res.setResponseStatus(constants.FAILURE);
			res.setResponseErrorCode(constants.INSERTION_FAILED);
			res.setResponseErrorMessage("Unable to insert records.");
			logger.debug("Unable to insert data");
			e.printStackTrace();
			return res;

		}

		return res;

	}

	public StatusResponse insertData(String title, String url, String desc) {
		StatusResponse res = null;

		return res;

	}

	/*
	 * public ParseContent getURL(String Url,String query_text) {
	 * 
	 * 
	 * ParsingUtils utils = new ParsingUtils(); ParseContent content=null;
	 * 
	 * 
	 * Document doc = utils.getDoc(Url, query_text);
	 * 
	 * List<Element> url = new ArrayList<Element>();
	 * 
	 * Elements links = doc.select("li[class=g]");
	 * 
	 * 
	 * for (Element link : links) {
	 * 
	 * content=new ParseContent();
	 * 
	 * 
	 * Elements urls=link.select("div[class=s]");
	 * 
	 * for (Element urltrim : urls) {
	 * 
	 * Elements formatURL=urltrim.getElementsByTag("cite");
	 * 
	 * url.addAll(formatURL); content.setUrls(url);
	 * 
	 * }
	 * 
	 * 
	 * } return content;
	 * 
	 * 
	 * }
	 * 
	 * public ParseContent getDescription(String Url,String query_text) {
	 * 
	 * 
	 * ParsingUtils utils = new ParsingUtils(); ParseContent content=null;
	 * 
	 * 
	 * Document doc = utils.getDoc(Url, query_text);
	 * 
	 * List<Element> desc = new ArrayList<Element>(); Elements links =
	 * doc.select("li[class=g]");
	 * 
	 * 
	 * for (Element link : links) {
	 * 
	 * content=new ParseContent();
	 * 
	 * 
	 * 
	 * Elements bodies = link.select("span[class=st]");
	 * //System.out.println("The Elements are:"+bodies.text());
	 * desc.addAll(bodies); content.setDescriptions(desc);
	 * 
	 * 
	 * } return content;
	 * 
	 * 
	 * }
	 * 
	 * public ParseContent getAddDesc(String Url,String query_text) {
	 * 
	 * 
	 * ParsingUtils utils = new ParsingUtils(); ParseContent content=null;
	 * 
	 * 
	 * Document doc = utils.getDoc(Url, query_text);
	 * 
	 * List<Element> description = new ArrayList<Element>();
	 * 
	 * Elements links = doc.select("li[class=g]");
	 * 
	 * 
	 * for (Element link : links) {
	 * 
	 * content=new ParseContent();
	 * 
	 * 
	 * Elements desc=link.select("div[class=s]");
	 * 
	 * for (Element addDesc : desc) {
	 * 
	 * Elements formatDesc=addDesc.getElementsByTag("br");
	 * System.out.println("The Additional DESC is:"+formatDesc.text());
	 * description.addAll(formatDesc); content.setDescriptions(desc);
	 * 
	 * }
	 * 
	 * 
	 * } return content;
	 * 
	 * 
	 * }
	 */
}