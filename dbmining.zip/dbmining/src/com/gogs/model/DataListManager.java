package com.gogs.model;

import java.sql.Connection;
import java.util.ArrayList;

import com.gogs.resource.dbDetails;

import com.gogs.dao.dbconnection;
import com.gogs.helpers.DataSearchHelper;

/**
 * 
 * @author gogs
 *
 */

public class DataListManager {

	public static ArrayList<dbDetails> getdbDataList(dbDetails detail)
			throws Exception {
		ArrayList<dbDetails> dataList = null;
		try {
			System.out.println("Entered in to DataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");
			DataSearchHelper data = new DataSearchHelper();
			System.out.println("DataList Handler Initiated...");

			dataList = data.DisplaySingleAttributesOnly(connection, detail);

			System.out
					.println("The Size of the DataList is:" + dataList.size());

			for (int i = 0; i < dataList.size(); i++) {
				System.out.println("The User List is..");
				System.out.println(dataList.get(i).toString());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return dataList;
	}

	public static ArrayList<dbDetails> getAlldbDataList(dbDetails detail)
			throws Exception {
		ArrayList<dbDetails> dataList = null;
		try {
			System.out.println("Entered in to AllDataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");
			DataSearchHelper data = new DataSearchHelper();
			System.out.println("DataList Handler Initiated...");

			dataList = data.DisplayAllResults(connection, detail);

			System.out
					.println("The Size of the DataList is:" + dataList.size());

			for (int i = 0; i < dataList.size(); i++) {
				System.out.println("The User List is..");
				System.out.println(dataList.get(i).toString());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return dataList;
	}

	public static ArrayList<dbDetails> getComparedbDataList(dbDetails detail)
			throws Exception {
		ArrayList<dbDetails> dataList = null;
		try {
			System.out.println("Entered in to AllDataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");
			DataSearchHelper data = new DataSearchHelper();
			System.out.println("DataList Handler Initiated...");

			dataList = data.CompareAttributes(connection, detail);

			System.out
					.println("The Size of the DataList is:" + dataList.size());

			for (int i = 0; i < dataList.size(); i++) {
				System.out.println("The User List is..");
				System.out.println(dataList.get(i).toString());
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return dataList;
	}

}