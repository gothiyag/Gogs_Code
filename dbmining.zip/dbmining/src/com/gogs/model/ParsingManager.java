package com.gogs.model;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.gogs.dao.dbconnection;
import com.gogs.helpers.DataSearchHelper;
import com.gogs.helpers.ParsingHelper;
import com.gogs.resource.InsertResponse;
import com.gogs.resource.StatusResponse;
import com.gogs.resource.dbDetails;

/**
 * 
 * @author gogs
 *
 */

public class ParsingManager {

	public static InsertResponse insertGoogleSearchResults(dbDetails detail)
			throws Exception {
		InsertResponse response = new InsertResponse();

		String googleSearch_url = "https://www.google.com/search?as_q";

		try {
			System.out.println("Entered in to DataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");

			ParsingHelper helper = new ParsingHelper();

			System.out
					.println("Parsing and Inserting GoogleSearch Results....");

			response = helper.googleSearchResults(googleSearch_url, detail,
					connection);

			System.out
					.println("The Size of the Response Status is:" + response);

			connection.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

	public static InsertResponse insertGoogleRelatedResults(dbDetails detail)
			throws Exception {

		InsertResponse response = new InsertResponse();
		String googleSearch_url = "https://www.google.com/search?as_q";

		try {
			System.out.println("Entered in to DataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");

			ParsingHelper helper = new ParsingHelper();

			System.out
					.println("Parsing and Inserting GoogleRelatedSearch Results....");

			response = helper.googleRelatedResults(googleSearch_url, detail,
					connection);

			connection.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

	public static InsertResponse insertBingSearchResults(dbDetails detail)
			throws Exception {
		InsertResponse response = new InsertResponse();

		try {
			System.out.println("Entered in to DataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");

			ParsingHelper helper = new ParsingHelper();

			System.out.println("Parsing and Inserting BingSearch Results....");

			response = helper.BingSearchResults("Web", detail, connection);

			connection.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

	public static InsertResponse insertBingRelatedResults(dbDetails detail)
			throws Exception {
		InsertResponse response = new InsertResponse();

		try {
			System.out.println("Entered in to DataList Manager Method..");
			dbconnection database = new dbconnection();
			Connection connection = database.getConnection();
			System.out.println("Database Connection Created..");

			ParsingHelper helper = new ParsingHelper();

			System.out
					.println("Parsing and Inserting BingRelatedSearch Results....");

			response = helper.BingSearchResults("RelatedSearch", detail,
					connection);

			connection.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return response;
	}

}
