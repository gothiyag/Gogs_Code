package com.gogs.resource;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author gogs
 *
 */

@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "SearchResponse")
public class InsertResponse extends StatusResponse implements
		RestServiceResponse {

	List<StatusResponse> insertResponse;

	/**
	 * @return the insertResponse
	 */
	public List<StatusResponse> getInsertResponse() {
		return insertResponse;
	}

	/**
	 * @param insertResponse
	 *            the insertResponse to set
	 */
	public void setInsertResponse(List<StatusResponse> insertResponse) {
		this.insertResponse = insertResponse;
	}

}
