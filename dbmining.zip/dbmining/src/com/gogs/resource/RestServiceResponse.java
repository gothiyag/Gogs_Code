package com.gogs.resource;

/**
 * 
 * @author gogs
 *
 */
public interface RestServiceResponse {

}
