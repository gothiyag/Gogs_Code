package com.gogs.resource;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 
 * @author gogs
 *
 */


@XmlAccessorType(XmlAccessType.NONE)
@XmlRootElement(name = "SearchResponse")
public class SearchResponse extends StatusResponse implements
		RestServiceResponse {

	List<dbDetails> searchDetails;

	/**
	 * @return the searchDetails
	 */
	@XmlElement
	public List<dbDetails> getSearchDetails() {
		return searchDetails;
	}

	/**
	 * @param searchDetails
	 *            the searchDetails to set
	 */
	public void setSearchDetails(List<dbDetails> searchDetails) {
		this.searchDetails = searchDetails;
	}

}
