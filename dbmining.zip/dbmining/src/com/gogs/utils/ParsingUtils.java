package com.gogs.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import java.net.URL;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Connection.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * 
 * @author gogs
 *
 */

public class ParsingUtils {

	public Document getDoc(String URLPath, String queryString) {

		Document doc = null;
		try {
			// doc =
			// Jsoup.connect("https://www.google.com/search?as_q=&as_epq=%22Yorkshire+Capital%22+&as_oq=fraud+OR+allegations+OR+scam&as_eq=&as_nlo=&as_nhi=&lr=lang_en&cr=countryCA&as_qdr=all&as_sitesearch=&as_occt=any&safe=images&tbs=&as_filetype=&as_rights=").userAgent("Mozilla").ignoreHttpErrors(true).timeout(0).get();
			doc = Jsoup.connect(URLPath + "=" + queryString)
					.userAgent("Mozilla").ignoreHttpErrors(true).timeout(0)
					.get();

			/*
			 * Response response= Jsoup.connect(URLPath+"="+queryString)
			 * .ignoreContentType(true) .userAgent(
			 * "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:25.0) Gecko/20100101 Firefox/25.0"
			 * ) .referrer("http://www.google.com") .timeout(12000)
			 * .followRedirects(true) .execute(); doc = response.parse();
			 */
		} catch (Exception e) {
			e.printStackTrace();
		}
		return doc;

	}

	/*
	 * public Connection getDBConnection(DBObject obj) throws SQLException {
	 * Connection con=null; String server = obj.getServerIp(); String dbname =
	 * obj.getDbName(); String port = obj.getPortNo(); String username =
	 * obj.getUserName(); String password = obj.getPassWord(); String url =
	 * "jdbc:mysql://"+server+":"+port+"/"+dbname;
	 * 
	 * try { con = DriverManager.getConnection(url, username, password); }
	 * catch(Exception e) { e.printStackTrace(); con.close(); }
	 * 
	 * 
	 * return con;
	 * 
	 * 
	 * }
	 */

	public static String getBingResults(String searchOption, String query) {
		String JsonResults = null;

		System.setProperty("http.proxyHost", "proxy_server_name");
		System.setProperty("http.proxyPort", "8080");
		String query_text = strReplace(query);
		String bingUrl = "https://api.datamarket.azure.com/Data.ashx/Bing/Search/"
				+ searchOption
				+ "?Query=%27"
				+ query_text
				+ "%27&$top=10&$format=Json";
		HttpClient httpclient = new DefaultHttpClient();
		String acc_key = "2XXWDk9Q1puNWe8dvRERT/6InjOSTRiPuUvCD2M6IUU=";
		byte[] accountKeyBytes = Base64
				.encodeBase64((":" + acc_key).getBytes());
		String enc_key = new String(accountKeyBytes);

		try {
			HttpGet httpget = new HttpGet(bingUrl);
			httpget.setHeader("Authorization", "Basic " + enc_key);
			System.out.println("executing request " + httpget.getURI());
			// Create a response handler
			ResponseHandler<String> responseHandler = new BasicResponseHandler();
			// String responseBody = httpclient.execute(httpget,
			// responseHandler);
			JsonResults = httpclient.execute(httpget, responseHandler);
			// String obj=JSONObject.escape(responseBody);
			System.out.println("----------------------------------------");
			System.out.println(JsonResults);
			System.out.println("----------------------------------------");

		} catch (IOException e) {
			System.out.println("Exception is" + e);
			e.printStackTrace();
		} finally {
			// When HttpClient instance is no longer needed,
			// shut down the connection manager to ensure
			// immediate deallocation of all system resources
			httpclient.getConnectionManager().shutdown();
		}

		return JsonResults;

	}

	public static String strReplace(String str) {
		String processed_string = str.replaceAll("\\s", "+");

		return processed_string;

	}

	public JSONArray getJSONObject(String SearchOption, String query_text)
			throws ParseException {

		JSONArray bingJsonObject = null;

		JSONParser parser = new JSONParser();
		JSONObject parsedJson = (JSONObject) parser.parse(getBingResults(
				SearchOption, query_text));

		JSONObject root_obj = (JSONObject) parsedJson.get("d");

		JSONArray obj = (JSONArray) root_obj.get("results");

		bingJsonObject = obj;

		return bingJsonObject;

	}

	public String googleURLEncoder(String URL) {
		String pre_text = "http://google.com";
		String formated_URL = pre_text
				+ URL.replaceAll("ie=UTF-8&", "").split("&revid=")[0];
		return formated_URL;
	}
}