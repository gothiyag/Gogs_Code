package com.gogs.ws;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;

import com.gogs.constants.constants;
import com.gogs.model.DataListManager;
import com.gogs.model.DataRelatedSearchManager;
import com.gogs.model.ParsingManager;

import com.gogs.resource.InsertResponse;
import com.gogs.resource.SearchResponse;
import com.gogs.resource.StatusResponse;

import com.gogs.resource.dbDetails;

import com.sun.jersey.spi.resource.Singleton;

/**
 * 
 * @author gogs
 *
 */

@Produces("application/xml")
@Path("results")
@Singleton
public class DBService {

	// private TreeMap<Integer, Customer> customerMap = new TreeMap<Integer,
	// Customer>();

	public DBService() {
		// hardcode a single customer into the database for demonstration
		// purposes
		/*
		 * Customer customer = new Customer();
		 * 
		 * customer.setName("Gogs"); customer.setAddress("US");
		 * customer.setName("Vikash"); customer.setAddress("Swiss");
		 * addCustomer(customer);
		 */
	}

	@POST
	@Path("SearchAndInsert")
	@Consumes("application/xml")
	public InsertResponse putdataList(dbDetails detail) {

		InsertResponse response = new InsertResponse();

		System.out.println("Entered in to putDataList Method..");

		try {

			response = ParsingManager.insertGoogleSearchResults(detail);
			response = ParsingManager.insertGoogleRelatedResults(detail);
			response = ParsingManager.insertBingSearchResults(detail);
			response = ParsingManager.insertBingRelatedResults(detail);

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_INSERTED);
			response.setResponseErrorMessage("Information Searched and Inserted Successfully.");

			/*
			 * List<StatusResponse> google_related = new
			 * ArrayList<StatusResponse>();
			 * 
			 * google_related =
			 * ParsingManager.insertGoogleRelatedResults(detail);
			 * 
			 * for(int j=0;j<google_related.size();j++) {
			 * response=google_related.get(j);
			 * 
			 * }
			 */
			// System.out.println("Gogs:"+response.getResponseStatus());

		} catch (Exception e) {
			e.printStackTrace();

			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.INSERTION_FAILED);
			response.setResponseErrorMessage("Not able to insert data...");
			return response;

		}
		return response;
	}

	/*
	 * @POST
	 * 
	 * @Path("searchresults/getResultsByAttr")
	 * 
	 * @Consumes("application/xml") public List<dbDetails> getdataList(dbDetails
	 * detail) { System.out.println("Entered in to getDataList Method..");
	 * List<dbDetails> data = new ArrayList<dbDetails>(); try { data =
	 * DataListManager.getdbDataList(detail);
	 * 
	 * } catch (Exception e) { e.printStackTrace(); } return data; }
	 */

	@POST
	@Path("searchresults/getResultsByAttr")
	@Consumes("application/xml")
	public SearchResponse getdataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataListManager.getdbDataList(detail);

			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");

			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();
			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

	@POST
	@Path("searchresults/getAllResultsSource")
	@Consumes("application/xml")
	public SearchResponse getAlldataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataListManager.getAlldbDataList(detail);

			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");
			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();
			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

	@POST
	@Path("searchresults/getCompareResultsByAttr")
	@Consumes("application/xml")
	public SearchResponse getComparedDataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataListManager.getComparedbDataList(detail);
			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");
			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();
			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

	@POST
	@Path("relatedresults/getResultsByAttr")
	@Consumes("application/xml")
	public SearchResponse getrelateddataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataRelatedSearchManager.getdbDataList(detail);

			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");
			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();

			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

	@POST
	@Path("relatedresults/getAllResultsSource")
	@Consumes("application/xml")
	public SearchResponse getAllRelatedDataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataRelatedSearchManager.getAlldbDataList(detail);

			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");
			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();

			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

	@POST
	@Path("relatedresults/getCompareResultsByAttr")
	@Consumes("application/xml")
	public SearchResponse getRelatedComparedDataList(dbDetails detail) {
		System.out.println("Entered in to getDataList Method..");
		SearchResponse response = new SearchResponse();
		List<dbDetails> data = new ArrayList<dbDetails>();
		try {
			data = DataRelatedSearchManager.getComparedbDataList(detail);
			if (data.size() == 0) {
				response.setResponseStatus(constants.FAILURE);
				response.setResponseErrorCode(constants.NO_DATA_FOUND);
				response.setResponseErrorMessage("No data matching query results.");
				return response;
			}

			response.setResponseStatus(constants.SUCCESS);
			response.setResponseErrorCode(constants.DATA_RETRIVED);
			response.setResponseErrorMessage("Information Retrived Successfully.");
			response.setSearchDetails(data);

		} catch (Exception e) {
			e.printStackTrace();
			response.setResponseStatus(constants.FAILURE);
			response.setResponseErrorCode(constants.NO_DATA_FOUND);
			response.setResponseErrorMessage("No data matching query results.");
			return response;
		}
		return response;
	}

}
